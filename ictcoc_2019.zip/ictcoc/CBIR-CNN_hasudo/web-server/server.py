# -*- coding: utf-8 -*-
import sys
sys.path.append("..")
from extract_cnn_vgg16_keras import VGGNet
import numpy as np

import h5py
import os
import  matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import argparse
import time

import flask
from flask import *
from flask.json import jsonify
# import cv2
from werkzeug.utils import secure_filename

import shutil, random

import tensorflow as tf

#CHANGE_DIRECTORY = "Caltech256"

class MyEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, bytes):
            return str(obj, encoding='utf-8');
        return json.JSONEncoder.default(self, obj)

def parse_opt():
    parser = argparse.ArgumentParser()
    parser.add_argument("-query", type=str, default='static/'+CHANGE_DIRECTORY+'/test_06122.jpg', help="Path to query which contains image to be queried")
    parser.add_argument("-index", type=str, default='static/'+CHANGE_DIRECTORY+'/featureCNN_map.h5' , help="Path to index")
    parser.add_argument("-result", type=str, default='static/'+CHANGE_DIRECTORY, help="Path for output retrieved images")
    parser.add_argument("-gpu", type=str, default="5", help='which gpu to use| set "" if use cpu')
    args = parser.parse_args()

    return args

app = flask.Flask("image-retrieval")

#os.environ["CUDA_DEVICE_ORDER"]="PCI_BUS_ID"
#os.environ["CUDA_VISIBLE_DEVICES"] = opt.gpu


def allowed_file(filename):
    ALLOWED_EXTENSIONS = set(['png', 'jpg', 'JPG', 'PNG', 'bmp', 'jpeg', 'JPEG'])
    return '.' in filename and filename.rsplit('.', 1)[1] in ALLOWED_EXTENSIONS

@app.route('/getrandomPicture2', methods=['GET','POST'])
def getrandomPicture2():
    if request.method == 'POST' :
        start_time = time.time()
        #image random data 가져오기
        basepath = os.path.dirname(__file__)
        upload_path = os.path.join(basepath, 'static/'+CHANGE_DIRECTORY)
        filenames = os.listdir(upload_path)
        #filenames = random.sample(os.listdir(upload_path ), 10)
        print("======================start")
        filenames.sort()
        print(filenames)
        
        print("======================end")
        returnImage = ""
        for i in range(len(filenames)):
            returnImage += filenames[i]+","

        print("Prediction cost", time.time() - start_time)
        return returnImage
    
@app.route('/getrandomPicture', methods=['GET','POST'])
def getrandomPicture():
    if request.method == 'POST' :
       start_time = time.time()
       #image random data 가져오기
       basepath = os.path.dirname(__file__)
       upload_path = os.path.join(basepath, 'static/'+CHANGE_DIRECTORY)
       #filenames = random.sample(os.listdir(upload_path+"/*.jpg"), 10)
       filenames = random.sample(os.listdir(upload_path ), 10)
       print(filenames)
       returnImage = ""
       for i in range(10):
        returnImage += filenames[i]+","

       print("Prediction cost", time.time() - start_time)
       return returnImage

@app.route('/upload2', methods=['POST', 'GET'])
def upload2():
    if request.method == 'POST':
        imageName = request.args.get('imageName')
        print(imageName)
        basepath = os.path.dirname(__file__)
        upload_path = os.path.join(basepath, 'static/'+CHANGE_DIRECTORY, imageName)
        start_time = time.time()
        im = get_preditction(upload_path)
        print("Prediction cost", time.time() - start_time)
        #return render_template('result.html',images=json.dumps(im,cls=MyEncoder),upload_image=secure_filename(imageName))
        return json.dumps(im,cls=MyEncoder)
    return render_template('result.html')

@app.route('/upload3', methods=['POST', 'GET'])
def upload3():
    if request.method == 'POST':
        imageName = request.args.get('imageName')
        print(imageName)
        basepath = os.path.dirname(__file__)
        upload_path = os.path.join(basepath, 'static/'+CHANGE_DIRECTORY, imageName)
        start_time = time.time()
        im = get_preditction2(upload_path)
        print("Prediction cost", time.time() - start_time)
        #return render_template('result.html',images=json.dumps(im,cls=MyEncoder),upload_image=secure_filename(imageName))
        return json.dumps(im,cls=MyEncoder)
    return render_template('result.html')

@app.route('/evaluate', methods=['POST', 'GET'])
def evaluate():
    return render_template('evaluate.html')

@app.route('/intro', methods=['POST', 'GET'])
def intro():
    return render_template('intro.html')

@app.route('/map', methods=['POST', 'GET'])
def map():
    return render_template('map.html')

@app.route('/map_test', methods=['POST', 'GET'])
def map_test():
    return render_template('map_test.html')

@app.route('/ai_map', methods=['POST', 'GET'])
def ai_map():
    return render_template('ai_map.html')

@app.route('/', methods=['POST', 'GET'])
def upload():
    if request.method == 'POST':
        f = request.files['file']
        if not (f and allowed_file(f.filename)):
            return jsonify({"error": 1001, "msg": "파일 확장자 다릅니다.png、PNG、jpg、JPG、bmp"})
        
        print(f.filename)
        
        basepath = os.path.dirname(__file__)

        upload_path = os.path.join(basepath, 'static/'+CHANGE_DIRECTORY, f.filename)
        # upload_path = os.path.join(basepath, 'static/images','test.jpg')
        f.save(upload_path)


        # img = cv2.imread(upload_path)
        # cv2.imwrite(os.path.join(basepath, 'app/static/images', 'test.jpg'), img)
        #img_url=os.path.join(basepath, 'static/'+CHANGE_DIRECTORY, 'test.jpg')
        # cv2.imwrite(img_url, img)
        start_time = time.time()
        print(upload_path)
        im = get_preditction(upload_path)
        print("Prediction cost", time.time() - start_time)
        # print(im)

        #return render_template('result.html',images=json.dumps(im,cls=MyEncoder),upload_image=secure_filename(f.filename))
        return json.dumps(im,cls=MyEncoder)

    return render_template('result.html')

def get_preditction2(img_url):
    print("--------------------------------------------------")
    print("               searching starts")
    print("--------------------------------------------------")

    # read and show query image
    basepath = os.path.dirname(__file__)
    queryDir = img_url
    queryImg = mpimg.imread(queryDir)

    # extract query image's feature, compute simlarity score and sort
    queryVec = model.extract_feat(queryDir)
    scores = np.dot(queryVec, feats.T)
    rank_ID = np.argsort(scores)[::-1]
    rank_score = scores[rank_ID]

    # number of top retrieved images to show
    #maxres = 15
    #print(enumerate(rank_ID[0:maxres]))
    #imlist = [imgNames[index] for i, index in enumerate(rank_ID[0:maxres])]
    #print(imlist[0])
    #print("top %d images in order are: " % maxres, imlist)
    #return imlist

    # number of top retrieved images to show
    #maxres = 15
    #print(enumerate(rank_ID[0:maxres]))
    imlist = []
    scorelist = []
    count_over = 0
    for i in range(len(rank_ID)):
        #if scores[rank_ID[i]] > 0.65:
        scorelist.append(scores[rank_ID[i]])
        index = rank_ID[i]
        imlist.append(imgNames[index])
        count_over = count_over + 1

    # imlist = [imgNames[index] for i, index in enumerate(rank_ID[0:maxres])]
    if len(imlist) > 0:
        print(imlist[0])
        print("top %d images in order are: " % count_over, imlist)
        print(scorelist)

    return imlist

def get_preditction(img_url):
    print("--------------------------------------------------")
    print("               searching starts")
    print("--------------------------------------------------")

    # read and show query image
    basepath = os.path.dirname(__file__)
    queryDir = img_url
    queryImg = mpimg.imread(queryDir)

    # extract query image's feature, compute simlarity score and sort
    queryVec = model.extract_feat(queryDir)
    scores = np.dot(queryVec, feats.T)
    rank_ID = np.argsort(scores)[::-1]
    rank_score = scores[rank_ID]

    # number of top retrieved images to show
    #maxres = 15
    #print(enumerate(rank_ID[0:maxres]))
    #imlist = [imgNames[index] for i, index in enumerate(rank_ID[0:maxres])]
    #print(imlist[0])
    #print("top %d images in order are: " % maxres, imlist)
    #return imlist

    # number of top retrieved images to show
    maxres = 15
    print(enumerate(rank_ID[0:maxres]))
    imlist = []
    scorelist = []
    count_over = 0
    for i in range(15):
        if scores[rank_ID[i]] > 0.65:
            scorelist.append(scores[rank_ID[i]])
            index = rank_ID[i]
            imlist.append(imgNames[index])
            count_over = count_over + 1

    # imlist = [imgNames[index] for i, index in enumerate(rank_ID[0:maxres])]
    if len(imlist) > 0:
        print(imlist[0])
        print("top %d images in order are: " % count_over, imlist)
        print(scorelist)

    return imlist

if __name__ == "__main__":
    CHANGE_DIRECTORY = "Caltech256"
    #CHANGE_DIRECTORY = "Caltech256_car"
    #CHANGE_DIRECTORY = "Caltech256_car"
    os.environ["CUDA_VISIBLE_DEVICES"] = "5"
    config = tf.ConfigProto()
    config.gpu_options.per_process_gpu_memory_fraction = 0.1
    tf.Session(config=config)

    opt = parse_opt()
    print(opt)
    print('Loading index...')
    # init VGGNet16 model
    model = VGGNet()
    start_time = time.time()
    h5f = h5py.File(opt.index, 'r')

    feats = h5f['feats'][:]
    imgNames = h5f['names'][:]

    h5f.close()
    print("finished loding index", time.time() - start_time)

    app.run(host="0.0.0.0", port=8000, debug=True)
    #app.run(host="127.0.0.1", port=7777, debug=True)