
from keras.applications.vgg16 import VGG16
from keras import backend as K

from tensorflow.python.keras.preprocessing import image
from tensorflow.python.keras.applications.vgg16 import preprocess_input, decode_predictions
import numpy as np

import cv2

NUM_CLASS = 3 # 0, 1, 2
model = VGG16(weights='imagenet')


class1_output = model.output[:, 1]

model.summary()

# e.g. 'block5_conv3' in VGG16 model
last_conv_layer = model.get_layer('block5_conv3') 


# 특정 클래스 c(여기서는 1)의 gradient ( dy/dA )
grads = K.gradients(class1_output, last_conv_layer.output)[0]

pooled_grads = K.mean(grads, axis=(0, 1, 2)) # 특성맵 채널별 gradient 평균값이 담긴 벡터

# 모델의 인풋을 입력으로 받고, pooled_grads와 컨볼루션 마지막층의 아웃풋을 출력으로 하는 함수설정
iterate = K.function([model.input],
					 [pooled_grads, last_conv_layer.output[0]])

img_path = './web-server/static/Caltech256/(10).jpg'
img = image.load_img(img_path, target_size = (224, 224))
x = image.img_to_array(img)
x = np.expand_dims(x, axis= 0) # (1, 224, 224, 3)
x = preprocess_input(x) # 데이터 전처리  - Imagenet의 전처리는 조금 다르다.

pooled_grads_value, conv_layer_output_value = iterate([x])

# 클래스 1번에 대한, 채널의 중요도를 특성 맵 배열의 채널에 곱합니다.
# linear combination
for i in range(NUM_CLASS):
	conv_layer_output_value[:, :, i] *= pooled_grads_value[i]

# 채널 축(axis=-1)에 따라서 평균한 값이 CAM 입니다.
heatmap = np.mean(conv_layer_output_value, axis=-1)
# ReLU
gradCAM = np.maximum(heatmap, 0)

# 0~1 사이로 정규화
gradCAM /= np.max(gradCAM)
#print(heatmap)
#plt.matshow(heatmap)


img = cv2.imread(img_path)
# heatmap을 원본 이미지 크기에 맞게 변경
heatmap = cv2.resize(heatmap, (img.shape[1], img.shape[0]))
# heatmap을 RGB 포맷으로 변환
heatmap = np.uint8(255 * heatmap)
# 히트맵으로 변환
heatmap = cv2.applyColorMap(heatmap, cv2.COLORMAP_JET)
# 0.4는 히트맵의 강도
superimposed_img = heatmap * 0.2 + img

cv2.imwrite('./web-server/static/Caltech256/(10)_heatmap.jpg', superimposed_img)
