# -*- coding: utf-8 -*-
from bottle import route, run, request, static_file, response

@route('/')
def Home():
    return static_file('index.html', root="static/")

@route('/static/<filepath:path>')
def server_static(filepath):
    return static_file(filepath, root='static/')

if __name__ == '__main__':
    run(port=80, host='0.0.0.0')
